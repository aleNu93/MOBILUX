using MOBILUX.Services;
using MOBILUX.Models;

namespace MOBILUX.Pages;

public partial class RegisterPage : ContentPage
{
    public RegisterPage()
    {
        InitializeComponent();
    }

    private async void OnSaveClicked(object sender, EventArgs e)
    {
        // --- Read all form fields ---
        var nombre        = FirstNameEntry.Text?.Trim();
        var apellido1     = LastName1Entry.Text?.Trim();
        var apellido2     = LastName2Entry.Text?.Trim();
        var cedula        = CedulaEntry.Text?.Trim();
        var telefono      = TelefonoEntry.Text?.Trim();
        var emailPrimario = PrimaryEmailEntry.Text?.Trim();
        var emailSecundario = SecondaryEmailEntry.Text?.Trim();
        var password      = PasswordEntry.Text;
        var confirmPass   = ConfirmPasswordEntry.Text;
        var fechaNac      = BirthDatePicker.Date;

        // --- Validations ---
        if (string.IsNullOrEmpty(nombre)    || string.IsNullOrEmpty(apellido1) ||
            string.IsNullOrEmpty(apellido2) || string.IsNullOrEmpty(cedula)    ||
            string.IsNullOrEmpty(telefono)  || string.IsNullOrEmpty(emailPrimario) ||
            string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Por favor complete todos los campos obligatorios.", "OK");
            return;
        }

        if (password != confirmPass)
        {
            await DisplayAlert("Error", "Las contraseñas no coinciden.", "OK");
            return;
        }

        if (password.Length < 8 || password.Length > 16)
        {
            await DisplayAlert("Error", "La contraseña debe tener entre 8 y 16 caracteres.", "OK");
            return;
        }

        try
        {
            var supabase = SupabaseService.Client;

            // ─────────────────────────────────────────────────────────
            // STEP 1: Create the Supabase Auth user.
            //
            // This creates a row in auth.users (managed by Supabase).
            // Supabase returns a User object with a unique UUID (user_id).
            // That UUID is the bridge between auth.users and tb_usuario.
            // ─────────────────────────────────────────────────────────
            var authResponse = await supabase.Auth.SignUp(emailPrimario, password);
            var userId = authResponse?.User?.Id
                ?? throw new Exception("No se pudo crear el usuario en Auth.");

            // ─────────────────────────────────────────────────────────
            // STEP 2: Insert into tb_usuario.
            //
            // We store the UUID from Auth so we can always link back.
            // Rol = "Cliente" for self-registered users.
            // ─────────────────────────────────────────────────────────
            var tbUsuario = new TbUsuario
            {
                UserId        = Guid.Parse(userId),
                Rol           = "Cliente",
                Activo        = true,
                FechaCreacion = DateTime.UtcNow
            };
            var usuarioResult = await supabase
                .From<TbUsuario>()
                .Insert(tbUsuario);

            var codigoUsuario = usuarioResult.Models.First().CodigoUsuario;

            // ─────────────────────────────────────────────────────────
            // STEP 3: Insert the primary email into the correo table.
            //
            // The correo table stores email addresses independently.
            // Then usuario_correo links a user to their emails,
            // allowing one user to have multiple emails.
            // ─────────────────────────────────────────────────────────
            var correoPrimario = new Correo { CorreoText = emailPrimario };
            var correoPrimarioResult = await supabase
                .From<Correo>()
                .Insert(correoPrimario);

            var codigoCorreoPrimario = correoPrimarioResult.Models.First().CodigoCorreo;

            // STEP 4: Link the user ↔ primary email in usuario_correo
            await supabase.From<UsuarioCorreo>().Insert(new UsuarioCorreo
            {
                CodigoUsuario = codigoUsuario,
                CodigoCorreo  = codigoCorreoPrimario,
                Tipo          = "Primario",
                Activo        = true
            });

            // STEP 5: If secondary email was provided, insert it too
            if (!string.IsNullOrEmpty(emailSecundario))
            {
                var correoSecundario = new Correo { CorreoText = emailSecundario };
                var correoSecundarioResult = await supabase
                    .From<Correo>()
                    .Insert(correoSecundario);

                var codigoCorreoSecundario = correoSecundarioResult.Models.First().CodigoCorreo;

                await supabase.From<UsuarioCorreo>().Insert(new UsuarioCorreo
                {
                    CodigoUsuario = codigoUsuario,
                    CodigoCorreo  = codigoCorreoSecundario,
                    Tipo          = "Secundario",
                    Activo        = true
                });
            }

            // ─────────────────────────────────────────────────────────
            // STEP 6: Insert into cliente.
            //
            // This is the "profile" table for users with rol = Cliente.
            // It links back to tb_usuario via codigo_usuario.
            // ─────────────────────────────────────────────────────────
            var cliente = new Cliente
            {
                CodigoUsuario   = codigoUsuario,
                Nombre          = nombre,
                Apellido1       = apellido1,
                Apellido2       = apellido2,
                Cedula          = cedula,
                FechaNacimiento = DateOnly.FromDateTime(fechaNac),
                Telefono        = telefono
            };
            await supabase.From<Cliente>().Insert(cliente);

            await DisplayAlert("Éxito", "¡Cuenta creada! Por favor inicie sesión.", "OK");
            await Shell.Current.GoToAsync("//login");
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }
}
