using MOBILUX.Services;

namespace MOBILUX.Pages;

public partial class LoginPage : ContentPage
{
    public LoginPage()
    {
        InitializeComponent();
    }

    private async void OnLoginClicked(object sender, EventArgs e)
    {
        var email = EmailEntry.Text?.Trim();
        var password = PasswordEntry.Text;

        // --- Validation ---
        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
        {
            await DisplayAlert("Error", "Please fill in all fields.", "OK");
            return;
        }

        try
        {
            // --- Call Supabase Auth ---
            // SignIn() sends the email+password to Supabase.
            // If valid, Supabase returns a session with a JWT token.
            // The SDK stores that token automatically — all future
            // database calls will include it, which is what makes
            // your RLS policies work ("I am this user").
            var session = await SupabaseService.Client.Auth.SignIn(email, password);

            if (session?.User != null)
            {
                await Shell.Current.GoToAsync("//dashboard");
            }
            else
            {
                await DisplayAlert("Error", "Invalid credentials.", "OK");
            }
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    private async void OnRecoverTapped(object sender, TappedEventArgs e)
    {
        await Shell.Current.GoToAsync("recover");
    }

    private async void OnRegisterTapped(object sender, TappedEventArgs e)
    {
        await Shell.Current.GoToAsync("register");
    }
}
