using MOBILUX.Services;

namespace MOBILUX.Pages;

public partial class PasswordUserRecoveryPage : ContentPage
{
    public PasswordUserRecoveryPage()
    {
        InitializeComponent();
    }

    // Show the info bubble as soon as the user types a valid-looking email
    private void OnRecoverEmailChanged(object sender, TextChangedEventArgs e)
    {
        var text = (e.NewTextValue ?? string.Empty).Trim();
        EmailSentBubble.IsVisible = text.Length >= 5 && text.Contains("@");
    }

    // ─────────────────────────────────────────────────────────────────
    // STEP 1: User presses "Enviar código"
    //
    // This tells Supabase Auth to send a recovery email to that address.
    // Supabase generates a one-time 6-digit OTP code and emails it.
    // The user then types that code into the CodeEntry field.
    // ─────────────────────────────────────────────────────────────────
    private async void OnSendCodeClicked(object sender, EventArgs e)
    {
        var email = RecoverEmailEntry.Text?.Trim();

        if (string.IsNullOrEmpty(email) || !email.Contains("@"))
        {
            await DisplayAlert("Error", "Por favor ingrese un correo válido.", "OK");
            return;
        }

        try
        {
            await SupabaseService.Client.Auth.ResetPasswordForEmail(email);
            await DisplayAlert("Enviado", "Revise su correo. Le llegará un código de recuperación.", "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // STEP 2: User presses "Guardar"
    //
    // VerifyOTP checks that the code the user typed matches what
    // Supabase sent. If valid, Supabase creates a temporary session.
    // Then we use that session to call Update() and set the new password.
    // ─────────────────────────────────────────────────────────────────
    private async void OnSaveClicked(object sender, EventArgs e)
    {
        var email           = RecoverEmailEntry.Text?.Trim();
        var code            = CodeEntry.Text?.Trim();
        var newPassword     = NewPasswordEntry.Text;
        var confirmPassword = ConfirmNewPasswordEntry.Text;

        // --- Validations ---
        if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(code) ||
            string.IsNullOrEmpty(newPassword))
        {
            await DisplayAlert("Error", "Por favor complete todos los campos.", "OK");
            return;
        }

        if (newPassword != confirmPassword)
        {
            await DisplayAlert("Error", "Las contraseñas no coinciden.", "OK");
            return;
        }

        if (newPassword.Length < 8 || newPassword.Length > 16)
        {
            await DisplayAlert("Error", "La contraseña debe tener entre 8 y 16 caracteres.", "OK");
            return;
        }

        try
        {
            var supabase = SupabaseService.Client;

            // Verify the OTP — this also signs the user in temporarily
            await supabase.Auth.VerifyOTP(
                email,
                code,
                Supabase.Gotrue.Constants.EmailOtpType.Recovery
            );

            // Now update the password using the temporary session
            await supabase.Auth.Update(new Supabase.Gotrue.UserAttributes
            {
                Password = newPassword
            });

            await DisplayAlert("Éxito", "¡Contraseña actualizada! Por favor inicie sesión.", "OK");
            await Shell.Current.GoToAsync("//login");
        }
        catch (Exception ex)
        {
            await DisplayAlert("Error", ex.Message, "OK");
        }
    }
}
