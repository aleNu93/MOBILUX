using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace MOBILUX.Models;

[Table("cliente")]
public class Cliente : BaseModel
{
    [PrimaryKey("codigo_cliente", false)]
    public long CodigoCliente { get; set; }

    [Column("codigo_usuario")]
    public long CodigoUsuario { get; set; }

    [Column("nombre")]
    public string Nombre { get; set; } = string.Empty;

    [Column("apellido_1")]
    public string Apellido1 { get; set; } = string.Empty;

    [Column("apellido_2")]
    public string Apellido2 { get; set; } = string.Empty;

    [Column("cedula")]
    public string Cedula { get; set; } = string.Empty;

    // DateOnly maps cleanly to Postgres DATE columns (no time component).
    [Column("fecha_nacimiento")]
    public DateOnly FechaNacimiento { get; set; }

    [Column("telefono")]
    public string Telefono { get; set; } = string.Empty;
}
