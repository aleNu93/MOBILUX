using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace MOBILUX.Models;

[Table("correo")]
public class Correo : BaseModel
{
    [PrimaryKey("codigo_correo", false)]
    public long CodigoCorreo { get; set; }

    // The column in Postgres is also called "correo", but we name the
    // C# property "CorreoText" to avoid confusion with the class name.
    [Column("correo")]
    public string CorreoText { get; set; } = string.Empty;
}
