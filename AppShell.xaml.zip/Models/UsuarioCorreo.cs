using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace MOBILUX.Models;

[Table("usuario_correo")]
public class UsuarioCorreo : BaseModel
{
    // This table has a composite primary key (codigo_usuario + codigo_correo).
    // We mark both columns with [PrimaryKey] and isIdentity=false because
    // neither is auto-generated — we supply both values ourselves.
    [PrimaryKey("codigo_usuario", false)]
    public long CodigoUsuario { get; set; }

    [PrimaryKey("codigo_correo", false)]
    public long CodigoCorreo { get; set; }

    [Column("tipo")]
    public string Tipo { get; set; } = "Primario"; // "Primario" or "Secundario"

    [Column("activo")]
    public bool Activo { get; set; } = true;
}
