using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace MOBILUX.Models;

// [Table("tb_usuario")] tells the SDK which Supabase table this class maps to.
[Table("tb_usuario")]
public class TbUsuario : BaseModel
{
    // [PrimaryKey(..., false)] — the 'false' means Supabase generates this value,
    // so we do NOT send it on INSERT. The SDK reads it back after inserting.
    [PrimaryKey("codigo_usuario", false)]
    public long CodigoUsuario { get; set; }

    // [Column("...")] maps the C# property to the exact column name in Postgres.
    [Column("user_id")]
    public Guid UserId { get; set; }

    [Column("rol")]
    public string Rol { get; set; } = "Cliente";

    [Column("activo")]
    public bool Activo { get; set; } = true;

    [Column("fecha_creacion")]
    public DateTime FechaCreacion { get; set; }
}
