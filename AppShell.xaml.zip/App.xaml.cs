﻿using MOBILUX.Services;

namespace MOBILUX;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new AppShell();

        // Fire and forget initialization
        Task.Run(async () => await SupabaseService.InitAsync());
    }
}
